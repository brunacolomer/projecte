1) Els jocs de proves públics de la pràctica es composen de:
  - README.txt : aquest mateix fitxer.
  - driver_easydial.cpp :  programa  principal que us  permetrà  provar
  les vostres classes.  Heu de compilar/linkar el driver  juntament amb
  les vostres classes/mòduls.
  - jp_public.tgz : pack  amb els fitxers que composen el joc de proves
  públic.  S'ha  de  descomprimir  al  directori  on  teniu  el  vostre 
  projecte.


2) El fitxer amb  els missatges d'error  "EasyDial.err" és utilizat pel 
driver  (driver_easydial.cpp) i ha d'estar  en el mateix  directori que
el programa executable obtingut  al compilar i montar el driver amb les
vostres classes i mòduls.


3) Recordeu que per tal que una projecte sigui avaluat  positivament ha
ha de passar els jocs de proves públics, és a dir, el fitxer de sortida
que generi  la  vostre  projecte  ha de ser exactament  igual al que us 
proporcionem (jp_public.res).


Per qualsevol dubte consulteu amb el professor de laboratori.
